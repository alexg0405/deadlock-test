﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace deadlock.external.Structs
{
    internal enum HeroIds
    {
        Infernus = 1,
        Seven,
        Vindicta,
        LadyGeist,
        Abrams = 6,
        Wraith,
        McGinnis,
        Paradox = 10,
        Dynamo,
        Kelvin,
        Haze,
        Holliday,
        Bebop,
        GreyTalon = 17,
        MoAndKrill,
        Shiv,
        Ivy,
        Warden = 25,
        Yamato = 27,
        Lash = 31,
        Viscous = 35,
        Wrecker = 48,
        Pocket = 50,
        Mirage = 52,
        Dummy = 55
    }
}
