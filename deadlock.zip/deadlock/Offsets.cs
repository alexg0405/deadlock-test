﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//AlexG0405 deadlock.external offsets, UPDATE THESE BASED ON DUMPER
namespace deadlock
{
    internal static class Offsets
    {
        internal static IntPtr dwEntityList = 0x1fc9680;
        internal static IntPtr ViewMatrix = 0x2192230;
        internal static IntPtr LocalPlayerController = 0x2180338;
        internal static IntPtr CCitadelCameraManager = 0x1fec090;

        internal static IntPtr m_boneArray = 0x80;
        //C_CitadelBaseAbility
        //CitadelHeroData_t
        //C_BaseModelEntity
        //C_BasePlayerWeapon
        //CCollisionProperty
        //CCitadelPlayer_ObserverServices
    }
}


