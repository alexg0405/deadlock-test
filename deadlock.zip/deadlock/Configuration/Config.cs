﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//AlexG0405 Deadlock.external
namespace deadlock.Configuration
{
    internal class Config
    {
        //not setup yet
    }
}
